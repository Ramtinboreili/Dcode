#!/bin/sh
# Install dcode from this folder. No network. Root installs for everyone; anyone else for themselves.
#   ./install.sh            /usr/local/bin as root, ~/.local/bin otherwise
#   ./install.sh /opt/bin   a folder of your choice
set -eu
HERE="$(cd "$(dirname "$0")" && pwd)"
if [ -n "${1:-}" ]; then DEST="$1"; elif [ "$(id -u)" -eq 0 ]; then DEST=/usr/local/bin; else DEST="${HOME}/.local/bin"; fi
mkdir -p "${DEST}"
install -m 0755 "${HERE}/dcode" "${DEST}/dcode"
echo "Installed ${DEST}/dcode ($("${DEST}/dcode" --version))"
case ":${PATH}:" in *":${DEST}:"*) ;; *) echo "Add it to your PATH:  export PATH=\"${DEST}:\$PATH\"" ;; esac
echo "Run: dcode"
